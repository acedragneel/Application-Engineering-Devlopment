/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abhi.mycompany.hospitalmodel.directory;

import com.abhi.mycompany.hospitalmodel.models.Patient;
import com.abhi.mycompany.hospitalmodel.models.Person;
import java.util.ArrayList;

/**
 *
 * @author abhilashgp
 */
public class PatientDirectory {
    
    ArrayList<Patient> directory;

    public PatientDirectory(ArrayList<Patient> directory) {
        this.directory = new ArrayList<>();
    }

    public ArrayList<Patient> getDirectory() {
        return directory;
    }

    public void setDirectory(ArrayList<Patient> directory) {
        this.directory = directory;
    }
    
    public Patient addNewPatient(String name,int patientId,Person person){
    Patient patient = new Patient(name,patientId,person);
    directory.add(patient);
    return patient;
    }

        
}
